# FocusGuard - Starter Android Project (Kotlin + Jetpack Compose)

This is a lightweight starter skeleton for the **FocusGuard** app described in your roadmap.
It's intended as a starting point you can open in Android Studio (Arctic Fox / Chipmunk / Dolphin or newer).

## What's included
- Minimal Gradle setup (root + app module)
- Simple Jetpack Compose `MainActivity` showing a dashboard placeholder
- String resources (English + Telugu)
- .github Actions workflow to build the project on push (Android/macOS runners)
- README with next steps

## How to use
1. Download and unzip the `focusguard_starter.zip`.
2. Open the folder in **Android Studio** (File → Open).
3. Let Android Studio sync Gradle. You may need to install/update the Android SDK and Kotlin plugin.
4. Run the `app` configuration on an emulator or device.

## Notes & Limitations
- This is a skeleton project to get you started. It includes placeholders and minimal code but not the full feature set.
- Some dependencies/versions in `build.gradle` are kept minimal — Android Studio might suggest updates.
- The GitHub Actions workflow attempts a standard Gradle build; you may need to adjust SDK versions or cache settings.

If you'd like, I can extend this skeleton to include more features (Room, Accessibility stubs, encrypted prefs) or generate a fuller app — tell me which modules you'd like next.
